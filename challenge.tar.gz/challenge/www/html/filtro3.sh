#!/bin/bash
# Proposito: Filtro por data do arquivo
# Autor: Oswaldo Galdino - og.junior@hotmail.com
# ------------------------------------------

  echo "content-type: text/html"
  echo
  echo
  echo "
  <html> <head> <title> Filtro 3 </title> </head>
  <body>
  "

  echo "<h2>Filtro por data do arquivo - Ex: 2022_03_10 ou 2023_03_10</h2>"
  if [ "$QUERY_STRING" ];then
        cliente="$(echo $QUERY_STRING | sed 's/\(.*=\)\(.*\)\(\&.*\)/\2/')"
        echo "<br>"
        echo "Pesquisando:<b>$cliente</b>"
        echo "<pre>"
        ls -lhtr /home/ubuntu/challenge-sre-2023 | grep -n $cliente
        echo "</pre>"
        echo "Fim."
  else
        echo "
        <form method=\"GET\" action=\"filtro3.cgi\">
        <b>Digite uma data e pressione ENTER - Ex: 2022_03_10 ou 2023_03_10:</b>
        <input size=40 name=host value=\"\">
        <input type=hidden size=40 name=teste value=\"resultado\">
        </form>"
  fi

  echo "</body>"
  echo "</html>"
