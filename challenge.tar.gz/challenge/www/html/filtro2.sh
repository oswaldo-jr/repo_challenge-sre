#!/bin/bash
# Proposito: Filtro por nome de cliente
# Autor: Oswaldo Galdino - og.junior@hotmail.com
# ------------------------------------------

  echo "content-type: text/html"
  echo
  echo
  echo "
  <html> <head> <title> Filtro 2 </title> </head>
  <body>
  "

  echo "<h2>Filtro por tipo de arquivo - Ex: calls ou metrics</h2>"
  if [ "$QUERY_STRING" ];then
        cliente="$(echo $QUERY_STRING | sed 's/\(.*=\)\(.*\)\(\&.*\)/\2/')"
        echo "<br>"
        echo "Pesquisando:<b>$arquivo</b>"
        echo "<pre>"
        ls /home/ubuntu/challenge-sre-2023 | grep $arquivo
        echo "</pre>"
        echo "Fim."
  else
        echo "
        <form method=\"GET\" action=\"filtro2.cgi\">
        <b>Digite o tipo de arquivo e pressione ENTER - Ex: calls ou metrics:</b>
        <input size=40 name=host value=\"\">
        <input type=hidden size=40 name=teste value=\"resultado\">
        </form>"
  fi

  echo "</body>"
  echo "</html>"
