#!/bin/bash
# Proposito: Filtro por nome de cliente
# Autor: Oswaldo Galdino - og.junior@hotmail.com
# -------------------------------------------------

  echo "content-type: text/html"
  echo
  echo
  echo "
  <html> <head> <title> Filtro 5 </title> </head>
  <body>
  "

  echo "<h2>Filtrar cliente com mais de 20 dias na base</h2>"
  if [ "$QUERY_STRING" ];then
        #echo "QUERY_STRING   $QUERY_STRING"
        cliente="$(echo $QUERY_STRING | sed 's/\(.*=\)\(.*\)\(\&.*\)/\2/')"
        echo "<br>"
        echo "Pesquisando:<b>$cliente</b>"
        echo "<pre>"
        ls -lhtr /home/ubuntu/challenge-sre-2023 | grep -v "2023_04"  | grep -n $cliente
        echo "</pre>"
        echo "Fim."
  else
        echo "
        <form method=\"GET\" action=\"filtro5.cgi\">
        <b>Digite o nome do cliente - Ex: cliente5 ou cliente10:</b>
        <input size=40 name=host value=\"\">
        <input type=hidden size=40 name=teste value=\"resultado\">
        </form>"
  fi

  echo "</body>"
  echo "</html>"
